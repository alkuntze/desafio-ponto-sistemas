            <footer id="rodape">
              <p>Copyright 2020 - by Alessandro Léo Kuntze <br/>
                <a href="https://www.facebook.com/alessandro.kuntze" target="_blank">Facebook</a> |
                <a href="https://www.linkedin.com/in/alessandro-l%C3%A9o-kuntze-19505a1a/" target="_blank">LinkedIn</a></p>
            </footer>        
        </div>
    </body>
</html>
